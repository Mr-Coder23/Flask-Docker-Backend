# Inside docker/frontend/
docker build -t your-dockerhub-username/frontend .
docker push your-dockerhub-username/frontend

# Inside docker/backend/
docker build -t your-dockerhub-username/backend .
docker push your-dockerhub-username/backend

