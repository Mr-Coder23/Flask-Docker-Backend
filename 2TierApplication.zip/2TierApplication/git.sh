git init
git remote add origin https://github.com/<your-username>/<repo-name>.git
git add .
git commit -m "Initial commit: Flask + Terraform + Docker setup"
git push -u origin master
